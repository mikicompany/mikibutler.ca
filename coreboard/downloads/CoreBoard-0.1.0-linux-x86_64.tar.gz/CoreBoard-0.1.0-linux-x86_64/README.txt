Core Board 0.1.0 — Linux (x86_64)

Run:
  ./coreboard

Optional desktop entry: copy coreboard.desktop to ~/.local/share/applications/
(edit Exec= to the full path of this coreboard binary).

Needs a desktop with the usual windowing libraries (libxkbcommon-x11, a GL/Vulkan driver)
and xdg-desktop-portal for the folder picker — any standard desktop already has these.
