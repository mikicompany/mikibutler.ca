Core Board 0.1.0 — Windows (x86_64, portable)

Run:
  Double-click coreboard.exe.

If Windows SmartScreen shows "Windows protected your PC", click
"More info" then "Run anyway" (the build isn't code-signed yet).

No install needed — your boards are saved under %APPDATA%\coreboard\.
